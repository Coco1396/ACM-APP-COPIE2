{\rtf1\ansi\ansicpg1252\cocoartf2639
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fnil\fcharset0 Menlo-Regular;}
{\colortbl;\red255\green255\blue255;\red0\green0\blue255;\red255\green255\blue254;\red0\green0\blue0;
\red144\green1\blue18;\red107\green0\blue1;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c100000;\cssrgb\c100000\c100000\c99608;\cssrgb\c0\c0\c0;
\cssrgb\c63922\c8235\c8235;\cssrgb\c50196\c0\c0;}
\paperw11900\paperh16840\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs26 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec2 export\cf0 \strokec4  \cf2 \strokec2 function\cf0 \strokec4  createPageUrl(pageName: \cf2 \strokec2 string\cf0 \strokec4 ) \{\cb1 \
\pard\pardeftab720\partightenfactor0
\cf0 \cb3     \cf2 \strokec2 return\cf0 \strokec4  \cf5 \strokec5 '/'\cf0 \strokec4  + pageName.replace(\cf6 \strokec6 / /\cf2 \strokec2 g\cf0 \strokec4 , \cf5 \strokec5 '-'\cf0 \strokec4 );\cb1 \
\cb3 \}\cb1 \
}